from time import strftime

def convert_time(start_time, end_time):
	to_return = []
	while start_time < end_time:
		to_return.append(start_time)
    	start_time += datetime.timedelta(minutes=30)
	return [t.strftime("%H:%M") for t in to_return] 
